import { db } from "../src/lib/db";

async function main() {
  console.log("Seeding database...");

  // Create sample products
  const products = [
    {
      name: "SaaS Starter Kit",
      description:
        "Template completo para criar seu SaaS em tempo recorde. Inclui autenticação, pagamentos, dashboard e muito mais. Código fonte limpo e bem documentado.",
      price: 197.0,
      type: "software",
      active: true,
    },
    {
      name: "TypeScript Avançado",
      description:
        "Curso completo de TypeScript para desenvolvedores que querem dominar a linguagem. 40+ horas de conteúdo, projetos práticos e certificado.",
      price: 297.0,
      type: "course",
      active: true,
    },
    {
      name: "Mentoria 1:1",
      description:
        "Sessões personalizadas de mentoria para acelerar sua carreira. Análise de código, planejamento de carreira e muito mais.",
      price: 500.0,
      type: "consulting",
      active: true,
    },
    {
      name: "API REST Pronta para Produção",
      description:
        "Boilerplate de API REST com Node.js, Express, autenticação JWT, testes e documentação automática. Pronto para deploy.",
      price: 147.0,
      type: "software",
      active: true,
    },
  ];

  for (const product of products) {
    await db.product.create({
      data: product,
    });
    console.log(`Created product: ${product.name}`);
  }

  // Create sample podcast episodes
  const episodes = [
    {
      title: "Pilot: Por que criamos o TechHub",
      description:
        "No primeiro episódio, discutimos a motivação por trás da criação da plataforma e o que você pode esperar dos próximos episódios.",
      episodeNumber: 1,
      duration: 1920, // 32 min
      publishedAt: new Date("2024-03-01"),
    },
    {
      title: "IA no Desenvolvimento: Ferramenta ou Substituto?",
      description:
        "Discussão profunda sobre o papel da IA no desenvolvimento de software e como se preparar para o futuro.",
      episodeNumber: 2,
      duration: 2700, // 45 min
      publishedAt: new Date("2024-03-08"),
    },
    {
      title: "Carreira Tech: Do Júnior ao Sênior",
      description:
        "Conversa sobre os desafios da evolução profissional e dicas práticas para acelerar sua jornada.",
      episodeNumber: 3,
      duration: 2280, // 38 min
      publishedAt: new Date("2024-03-15"),
    },
    {
      title: "Arquitetura de Software: Princípios que Importam",
      description:
        "Exploramos princípios fundamentais de arquitetura e quando aplicá-los na prática.",
      episodeNumber: 4,
      duration: 3120, // 52 min
      publishedAt: new Date("2024-03-22"),
    },
  ];

  for (const episode of episodes) {
    await db.podcastEpisode.create({
      data: episode,
    });
    console.log(`Created episode: ${episode.title}`);
  }

  console.log("Seeding completed!");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
